// IdealDlg.cpp : implementation file
//

#include "stdafx.h"
#include "zyb560.h"
#include "IdealDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIdealDlg dialog


CIdealDlg::CIdealDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CIdealDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIdealDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CIdealDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIdealDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CIdealDlg, CDialog)
	//{{AFX_MSG_MAP(CIdealDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIdealDlg message handlers
void Ideal_Filter_FFT(int D);
void CIdealDlg::OnOK() 
{
	// TODO: Add extra validation here
	int num ;
	char str[10];
	GetDlgItem(IDC_EDIT1)->GetWindowText(str,10);
	if(str[0] != '-'){
		num = atoi(str);
	}else{
		int i=1;
		char c[10];
		while(str[i] != '\0'){
			c[i-1] = str[i++];
		}
		c[i] = '\0';
		num = -atoi(c);
	}
	Ideal_Filter_FFT(num);
	
	EndDialog(1);
}
