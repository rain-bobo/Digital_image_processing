// zyb560View.h : interface of the CZyb560View class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ZYB560VIEW_H__FEB7F8DE_631B_4F62_BEFF_E5086C091614__INCLUDED_)
#define AFX_ZYB560VIEW_H__FEB7F8DE_631B_4F62_BEFF_E5086C091614__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CZyb560View : public CScrollView
{
protected: // create from serialization only
	CZyb560View();
	DECLARE_DYNCREATE(CZyb560View)

// Attributes
public:
	CZyb560Doc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CZyb560View)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CZyb560View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CZyb560View)
	afx_msg void OnGray();
	afx_msg void OnUpdateGray(CCmdUI* pCmdUI);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnHistogram();
	afx_msg void OnUpdateHistogram(CCmdUI* pCmdUI);
	afx_msg void OnEqualize();
	afx_msg void OnUpdateEqualize(CCmdUI* pCmdUI);
	afx_msg void OnLinertrans();
	afx_msg void OnUpdateLinertrans(CCmdUI* pCmdUI);
	afx_msg void OnFourier();
	afx_msg void OnUpdateFourier(CCmdUI* pCmdUI);
	afx_msg void OnIfourier();
	afx_msg void OnUpdateIfourier(CCmdUI* pCmdUI);
	afx_msg void OnAveragefilter();
	afx_msg void OnUpdateAveragefilter(CCmdUI* pCmdUI);
	afx_msg void OnMedianfilter();
	afx_msg void OnUpdateMedianfilter(CCmdUI* pCmdUI);
	afx_msg void OnGradsharp();
	afx_msg void OnUpdateGradsharp(CCmdUI* pCmdUI);
	afx_msg void OnRaplassharp();
	afx_msg void OnUpdateRaplassharp(CCmdUI* pCmdUI);
	afx_msg void OnIfft();
	afx_msg void OnUpdateIfft(CCmdUI* pCmdUI);
	afx_msg void OnFft();
	afx_msg void OnUpdateFft(CCmdUI* pCmdUI);
	afx_msg void OnIdealfilter();
	afx_msg void OnUpdateIdealfilter(CCmdUI* pCmdUI);
	afx_msg void OnButterworthfilter();
	afx_msg void OnUpdateButterworthfilter(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in zyb560View.cpp
inline CZyb560Doc* CZyb560View::GetDocument()
   { return (CZyb560Doc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ZYB560VIEW_H__FEB7F8DE_631B_4F62_BEFF_E5086C091614__INCLUDED_)
