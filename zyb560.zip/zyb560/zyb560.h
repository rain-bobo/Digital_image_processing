// zyb560.h : main header file for the ZYB560 application
//

#if !defined(AFX_ZYB560_H__7D9818EE_D368_4CA3_8450_F404BA82E799__INCLUDED_)
#define AFX_ZYB560_H__7D9818EE_D368_4CA3_8450_F404BA82E799__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CZyb560App:
// See zyb560.cpp for the implementation of this class
//

class CZyb560App : public CWinApp
{
public:
	CZyb560App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CZyb560App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CZyb560App)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ZYB560_H__7D9818EE_D368_4CA3_8450_F404BA82E799__INCLUDED_)
