// zyb560View.cpp : implementation of the CZyb560View class
//

#include "stdafx.h"
#include "zyb560.h"
#include "HistogramDlg.h"
#include "zyb560Doc.h"
#include "zyb560View.h"
#include "IdealDlg.h"
#include "LinerDlg.h"
#include "BUTTERWORTHFILTERDLG.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CZyb560View

IMPLEMENT_DYNCREATE(CZyb560View, CScrollView)

BEGIN_MESSAGE_MAP(CZyb560View, CScrollView)
	//{{AFX_MSG_MAP(CZyb560View)
	ON_COMMAND(ID_GRAY, OnGray)
	ON_UPDATE_COMMAND_UI(ID_GRAY, OnUpdateGray)
	ON_WM_MOUSEMOVE()
	ON_COMMAND(ID_HISTOGRAM, OnHistogram)
	ON_UPDATE_COMMAND_UI(ID_HISTOGRAM, OnUpdateHistogram)
	ON_COMMAND(ID_EQUALIZE, OnEqualize)
	ON_UPDATE_COMMAND_UI(ID_EQUALIZE, OnUpdateEqualize)
	ON_COMMAND(ID_LINERTRANS, OnLinertrans)
	ON_UPDATE_COMMAND_UI(ID_LINERTRANS, OnUpdateLinertrans)
	ON_COMMAND(ID_FOURIER, OnFourier)
	ON_UPDATE_COMMAND_UI(ID_FOURIER, OnUpdateFourier)
	ON_COMMAND(ID_IFOURIER, OnIfourier)
	ON_UPDATE_COMMAND_UI(ID_IFOURIER, OnUpdateIfourier)
	ON_COMMAND(ID_AVERAGEFILTER, OnAveragefilter)
	ON_UPDATE_COMMAND_UI(ID_AVERAGEFILTER, OnUpdateAveragefilter)
	ON_COMMAND(ID_MEDIANFILTER, OnMedianfilter)
	ON_UPDATE_COMMAND_UI(ID_MEDIANFILTER, OnUpdateMedianfilter)
	ON_COMMAND(ID_GRADSHARP, OnGradsharp)
	ON_UPDATE_COMMAND_UI(ID_GRADSHARP, OnUpdateGradsharp)
	ON_COMMAND(ID_RAPLASSHARP, OnRaplassharp)
	ON_UPDATE_COMMAND_UI(ID_RAPLASSHARP, OnUpdateRaplassharp)
	ON_COMMAND(ID_IFFT, OnIfft)
	ON_UPDATE_COMMAND_UI(ID_IFFT, OnUpdateIfft)
	ON_COMMAND(ID_FFT, OnFft)
	ON_UPDATE_COMMAND_UI(ID_FFT, OnUpdateFft)
	ON_COMMAND(ID_IDEALFILTER, OnIdealfilter)
	ON_UPDATE_COMMAND_UI(ID_IDEALFILTER, OnUpdateIdealfilter)
	ON_COMMAND(ID_BUTTERWORTHFILTER, OnButterworthfilter)
	ON_UPDATE_COMMAND_UI(ID_BUTTERWORTHFILTER, OnUpdateButterworthfilter)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CZyb560View construction/destruction

CZyb560View::CZyb560View()
{
	// TODO: add construction code here

}

CZyb560View::~CZyb560View()
{
}

BOOL CZyb560View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CZyb560View drawing
extern BITMAPINFO *lpBitsInfo;
extern BITMAPINFO *lpDIB_FFT;
extern BITMAPINFO *lpDIB_IFFT;
void CZyb560View::OnDraw(CDC* pDC)
{
	CZyb560Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here

	if(NULL == lpBitsInfo)
		return;

	LPVOID lpBits = (LPVOID)&lpBitsInfo->bmiColors[lpBitsInfo->bmiHeader.biClrUsed];
	StretchDIBits(
		pDC->GetSafeHdc(),
		0,0,
		lpBitsInfo->bmiHeader.biWidth,
		lpBitsInfo->bmiHeader.biHeight,
		0,0,
		lpBitsInfo->bmiHeader.biWidth,
		lpBitsInfo->bmiHeader.biHeight,
		lpBits,
		lpBitsInfo,
		DIB_RGB_COLORS,
		SRCCOPY);
	if (lpDIB_FFT)
	{
		lpBits = (LPVOID)&lpDIB_FFT->bmiColors[lpDIB_FFT->bmiHeader.biClrUsed];
		StretchDIBits( 
			pDC->GetSafeHdc(),
			600,0,
			lpDIB_FFT->bmiHeader.biWidth,
			lpDIB_FFT->bmiHeader.biHeight,
			0,0,
			lpDIB_FFT->bmiHeader.biWidth,
			lpDIB_FFT->bmiHeader.biHeight,
			lpBits,
			lpDIB_FFT, // bitmap data 
			DIB_RGB_COLORS,
			SRCCOPY);
	}

	if (lpDIB_IFFT)
	{
		lpBits = (LPVOID)&lpDIB_IFFT->bmiColors[lpDIB_IFFT->bmiHeader.biClrUsed];
		StretchDIBits( 
			pDC->GetSafeHdc(),
			0,600,
			lpDIB_IFFT->bmiHeader.biWidth,
			lpDIB_IFFT->bmiHeader.biHeight,
			0,0,
			lpDIB_IFFT->bmiHeader.biWidth,
			lpDIB_IFFT->bmiHeader.biHeight,
			lpBits,
			lpDIB_IFFT, // bitmap data 
			DIB_RGB_COLORS,
			SRCCOPY);
	}
}

void CZyb560View::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	CSize sizeTotal;
	// TODO: calculate the total size of this view
	sizeTotal.cx = sizeTotal.cy = 10000;
	SetScrollSizes(MM_TEXT, sizeTotal);
}

/////////////////////////////////////////////////////////////////////////////
// CZyb560View diagnostics

#ifdef _DEBUG
void CZyb560View::AssertValid() const
{
	CScrollView::AssertValid();
}

void CZyb560View::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CZyb560Doc* CZyb560View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CZyb560Doc)));
	return (CZyb560Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CZyb560View message handlers
void Gray ();
void CZyb560View::OnGray() 
{
	// TODO: Add your command handler code here
	Gray ();
	Invalidate();
}

void CZyb560View::OnUpdateGray(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(lpBitsInfo != NULL && lpBitsInfo->bmiHeader.biBitCount == 24);
}

void pixel(int i,int j,char* str);
void CZyb560View::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	char xy[100];
	memset(xy, 0,100);
	sprintf(xy , " x: %d y : %d	" ,point.x, point.y);
	
	//��¼��ɫֵ
	char rgb[100];
	memset(rgb,0,100);
	pixel(point.y, point.x, rgb);
	
	//��������ɫֵ�ϲ�
	strcat (xy, rgb);
	
	//��״̬������ʾ
	((CFrameWnd*)GetParent())->SetMessageText(xy);

	CScrollView::OnMouseMove(nFlags, point);
}

void CZyb560View::OnHistogram() 
{
	// TODO: Add your command handler code here
	CHistogramDlg dlg;
	dlg.DoModal();

}
BOOL IsGray();
void CZyb560View::OnUpdateHistogram(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(lpBitsInfo != NULL && IsGray());
}
void Equalize();
void CZyb560View::OnEqualize() 
{
	// TODO: Add your command handler code here
	Equalize();
	Invalidate();
}

void CZyb560View::OnUpdateEqualize(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(lpBitsInfo != NULL && IsGray());
}

void CZyb560View::OnLinertrans() 
{
	// TODO: Add your command handler code here
	CLinerDlg dlg;
	dlg.DoModal();
	Invalidate();
}

void CZyb560View::OnUpdateLinertrans(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(lpBitsInfo != NULL && IsGray());
}
void Fourier();
void CZyb560View::OnFourier() 
{
	// TODO: Add your command handler code here
	Fourier();
	Invalidate();
}

void CZyb560View::OnUpdateFourier(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(lpBitsInfo != NULL && IsGray());
}
void IFourier();
void CZyb560View::OnIfourier() 
{
	// TODO: Add your command handler code here
	IFourier();
	Invalidate();
}
BOOL gFD_isValid();
void CZyb560View::OnUpdateIfourier(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(gFD_isValid());
}

void AverageFilter();
void CZyb560View::OnAveragefilter() 
{
	// TODO: Add your command handler code here
	AverageFilter();
	Invalidate();
}

void CZyb560View::OnUpdateAveragefilter(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(lpBitsInfo != NULL && IsGray());
}

void MedianFilter();
void CZyb560View::OnMedianfilter() 
{
	// TODO: Add your command handler code here
	MedianFilter();
	Invalidate();
}

void CZyb560View::OnUpdateMedianfilter(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(lpBitsInfo != NULL && IsGray());
}

void GradSharp();
void CZyb560View::OnGradsharp() 
{
	// TODO: Add your command handler code here
	GradSharp();
	Invalidate();
}

void CZyb560View::OnUpdateGradsharp(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(lpBitsInfo != NULL && IsGray());	
}

void RaplasSharp();
void CZyb560View::OnRaplassharp() 
{
	// TODO: Add your command handler code here
	RaplasSharp();
	Invalidate();
}

void CZyb560View::OnUpdateRaplassharp(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(lpBitsInfo != NULL && IsGray());		
}

void FFourier();
void IFFourier();
void CZyb560View::OnIfft() 
{
	// TODO: Add your command handler code here
	IFFourier();
	Invalidate();
}

void CZyb560View::OnUpdateIfft(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(gFD_isValid());
}

void CZyb560View::OnFft() 
{
	// TODO: Add your command handler code here
	FFourier();
	Invalidate();
}

void CZyb560View::OnUpdateFft(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(lpBitsInfo != NULL && IsGray()); 
}

void CZyb560View::OnIdealfilter() 
{
	// TODO: Add your command handler code here
	CIdealDlg dlg;
	dlg.DoModal();
	Invalidate();
}

void CZyb560View::OnUpdateIdealfilter(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(gFD_isValid());
}

void CZyb560View::OnButterworthfilter() 
{
	// TODO: Add your command handler code here
	CBUTTERWORTHFILTERDLG dlg;
	dlg.DoModal();
	Invalidate();
}

void CZyb560View::OnUpdateButterworthfilter(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(gFD_isValid()&& lpBitsInfo->bmiHeader.biBitCount == 8);
}
