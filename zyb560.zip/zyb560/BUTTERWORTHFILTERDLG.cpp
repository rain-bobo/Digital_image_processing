// BUTTERWORTHFILTERDLG.cpp : implementation file
//

#include "stdafx.h"
#include "zyb560.h"
#include "BUTTERWORTHFILTERDLG.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBUTTERWORTHFILTERDLG dialog


CBUTTERWORTHFILTERDLG::CBUTTERWORTHFILTERDLG(CWnd* pParent /*=NULL*/)
	: CDialog(CBUTTERWORTHFILTERDLG::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBUTTERWORTHFILTERDLG)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CBUTTERWORTHFILTERDLG::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBUTTERWORTHFILTERDLG)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBUTTERWORTHFILTERDLG, CDialog)
	//{{AFX_MSG_MAP(CBUTTERWORTHFILTERDLG)
	ON_BN_CLICKED(IDOK, OnBWFOK)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBUTTERWORTHFILTERDLG message handlers
void ButterWorth_Filter_FFT(int ,int);
void CBUTTERWORTHFILTERDLG::OnBWFOK() 
{
	// TODO: Add your control notification handler code here
	int d = GetDlgItemInt(IDC_BWF_EDIT1);
	int n = GetDlgItemInt(IDC_BWF_EDIT2);
	ButterWorth_Filter_FFT(d,n);

	EndDialog(1);
}
