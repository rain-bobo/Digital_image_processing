// LinerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "zyb560.h"
#include "LinerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLinerDlg dialog


CLinerDlg::CLinerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLinerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLinerDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CLinerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLinerDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLinerDlg, CDialog)
	//{{AFX_MSG_MAP(CLinerDlg)
	ON_BN_CLICKED(IDOK, OnLinerOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLinerDlg message handlers
void LinerTrans(float,float);
void CLinerDlg::OnLinerOk() 
{

	// TODO: Add your control notification handler code here
	char c1[10],c2[10];
	GetDlgItemText(IDC_LinerEDIT1, c1, 10);
	GetDlgItemText(IDC_LinerEDIT2, c2, 10);

	float a = (float)atof(c1);
	float b = (float)atof(c2);
	LinerTrans(a,b);
	EndDialog(1);
}
