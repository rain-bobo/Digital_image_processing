#if !defined(AFX_IDEALDLG_H__3F5C9F30_05D6_496C_A739_A06A5BD25BB2__INCLUDED_)
#define AFX_IDEALDLG_H__3F5C9F30_05D6_496C_A739_A06A5BD25BB2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// IdealDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CIdealDlg dialog

class CIdealDlg : public CDialog
{
// Construction
public:
	CIdealDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CIdealDlg)
	enum { IDD = IDD_DIALOG2 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIdealDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CIdealDlg)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IDEALDLG_H__3F5C9F30_05D6_496C_A739_A06A5BD25BB2__INCLUDED_)
