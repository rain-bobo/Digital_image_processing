//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by zyb560.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_ZYB560TYPE                  129
#define IDD_DIALOG1                     132
#define IDB_BITMAP1                     133
#define IDD_DIALOG2                     134
#define IDD_DIALOG3                     135
#define IDD_DIALOG4                     136
#define IDC_EDIT1                       1000
#define IDC_LinerEDIT2                  1001
#define IDC_BWF_EDIT2                   1001
#define IDC_LinerEDIT1                  1002
#define IDC_BWF_EDIT1                   1003
#define ID_GRAY                         32773
#define ID_HISTOGRAM                    32774
#define ID_LINERTRANS                   32775
#define ID_EQUALIZE                     32776
#define ID_FOURIER                      32777
#define ID_IFOURIER                     32778
#define ID_AVERAGEFILTER                32780
#define ID_MEDIANFILTER                 32781
#define ID_GRADSHARP                    32782
#define ID_RAPLASSHARP                  32783
#define ID_FFT                          32785
#define ID_IFFT                         32786
#define ID_IDEALFILTER                  32789
#define ID_BUTTERWORTHFILTER            32790

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32791
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
